
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'doctorew',
  applicationName: 'minimester-graphql',
  appUid: 'yBcYsFYPbxkgL5cyLZ',
  orgUid: '3b543866-0d5a-45a4-b04e-c13823a01d92',
  deploymentUid: 'd3709776-f57a-4900-9fce-b776d2ffa2aa',
  serviceName: 'minimester-graph-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'minimester-graph-lambda-dev-myFunction', timeout: 6 };

try {
  const userHandler = require('./dist/server-lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}